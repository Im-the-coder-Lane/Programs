// Programmer:		Jahmier Lane-Johnson
// Date:			3/24/24
// Program Name:	2D Rainfall
// Chapter:			Chapter 5 - Array
// Description:		A program to total the rainfall for 5 years and to average the rainfall for each month.
//					I use a lot of loops. 

#define _CRT_SECURE_NO_WARNINGS // Disable warnings (and errors) when using non-secure versions of printf, scanf, strcpy, etc.
#include <stdio.h> // Needed for working with printf and scanf

int main(void)
{
	// Constant and Variable Declarations

	// Constants
	const int ROW_NUM = 12;
	const int COL_NUM = 5;
	
	// Array

	double numArray[5][12] = { {0.88,1.11,2.01,3.64,6.44,5.58,4.23,4.34,4.00,2.05,1.48,0.77},{0.76,0.94,2.09,3.29,4.68,3.52,3.52,4.82,3.72,2.21,1.24,0.80},{0.67 ,0.80 ,1.75 ,2.70 ,4.01 ,3.88 ,3.72,3.78,3.55,1.88 ,1.21,0.61}, {0.82,  0.80,  1.99,  3.05, 4.19 ,4.44, 3.98 ,4.57, 3.43,2.32,1.61,0.75},{0.72, 0.90, 1.71, 2.02, 2.33,  2.98,  2.65, 2.99, 2.55, 1.99, 1.05,0.92}};
	char months[13][4] = {"Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"};
	int years[6] = { 2015, 2016, 2017, 2018, 2019 };

	// Calculated variable 
	double totalNum = 0.0;
	double avgNum = 0.0;


	// *** Your program goes here ***


	// Displaying the months
	for (int i = 0; i < ROW_NUM; i++) {
		printf("\t%s", months[i]);
	}
	printf("\n"); ; // blank line


	for (int i = 0; i < COL_NUM; i++)
	{
		printf("%d\t", years[i]); // Displaying the years
		for (int j = 0; j < ROW_NUM; j++)
		{
			printf("%.2lf\t", numArray[i][j]); // Displaying the rainfall numbers per row 
			

		}
		printf("\n"); // blank line
	}

	printf("\n"); // blank line
	printf("Total rainfall for each year:\n");


	for (int i = 0; i < COL_NUM; i++) // Loop for rainfall year total
	{
		printf("%d\t", years[i]); // Display years
		for (int j = 0; j < ROW_NUM; j++)
		{
		totalNum = totalNum + numArray[i][j];

		}
		printf("%.2lf\n", totalNum);
		totalNum = 0;
	}

	printf("\n"); // blank line

	printf("Average rainfall for each month:\n");

	for (int i = 0; i < ROW_NUM; i++)  // Display months
	{
		printf("%s\t", months[i]);
	}
	printf("\n"); // blank line

	for (int i = 0; i < ROW_NUM; i++) // Loop for rainfall month avg
	{
		totalNum = 0;
		for (int j = 0; j < COL_NUM; j++) {
			totalNum += numArray[j][i];
		}
		printf("%.2f\t", totalNum / 5);
	}
	printf("\n"); // blank line

	

	printf("\n"); // blank line

	return 0;
} // end main()
